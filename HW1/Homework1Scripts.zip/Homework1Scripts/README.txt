This contains my submission for Homework 1

problem1script_16B.m contains my reproduction of 1.6B
	along with what happens when you vary the parameters

problem1script_17B.m contains my reproduction of 1.7B
	along with what happens when you vary the parameters

problem2script.m contains what I did for problem 2

Every other file is just a helper function for problem2script.m

The file radtodeg.m has been included because some versions of matlab
    don't have the function radtodeg which changes radians to degrees.