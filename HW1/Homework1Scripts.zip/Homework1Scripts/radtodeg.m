function [ deg ] = radtodeg( rad )
%RADTODEG Summary of this function goes here
%   Detailed explanation goes here

deg = rad*180/pi;

end

